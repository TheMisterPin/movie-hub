import styled from "styled-components";

export const RecentGrid = styled.ul`

    display: grid;
    list-style: none;
    padding-left: 1rem;
    grid-template-columns: repeat(2, 11rem);

    
`


