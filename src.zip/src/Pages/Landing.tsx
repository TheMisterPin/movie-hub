import { useState } from "react";
import { LandingForm } from "../components/forms/LandingForm"
import { LoginForm } from "../components/forms/LoginForm";
import { SignUpForm } from "../components/forms/SignUpForm";
import { LandingContainer } from "../styled components/LandingContainer";

  export const Landing = () => {
    const [currentForm, setCurrentForm] = useState('landing'); 
  
    const renderForm = () => {
      switch (currentForm) {
        case 'login':
          return <LoginForm />;
        case 'register':
          return <SignUpForm />;
        default:
          return <LandingForm setCurrentForm={setCurrentForm} />;
      }
    };
  
    return (
      <LandingContainer>
        {renderForm()}
      </LandingContainer>
    );
  };
  

