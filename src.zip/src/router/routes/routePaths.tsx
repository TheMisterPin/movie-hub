export const LANDING = '/landing';
export const LOGIN = '/login';
export const REGISTER = '/register';
export const HOME = '/home'; 
export const LANDINGFORM='/landingForm'
export const MOVIEDETAILS = '/movies/movie/:title'
export const MOVIE = '/movies'
export const UPLOAD= '/upload'
export const USER = '/users/user/:username'


// direct access

