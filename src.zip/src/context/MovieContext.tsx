import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';



export type Movie = {
  id: string;
  title: string;
  rating: number;
  votes: number;
  description: string;
  poster: string;
  genre: string;
  length: number;
  trailer: string;
  year: number;
};
export type MovieData = {
  title: string;
  rating: number;
  votes: number;
  description: string;
  poster: string;
  genre: string;
  length: number;
  trailer: string;
  year: number;
};

export type MoviesContextType = {
  movies: Movie[];
  favorites: Movie[];
  recents: Movie[];
  fetchMovieByTitle: (title: string) => Promise<void>;
  selectedMovie: Movie | null;
  uploadMovie: (movieData: Omit<Movie, 'id'>) => Promise<void>;
};

const MoviesContext = createContext<MoviesContextType>({
  movies: [],
  favorites: [],
  recents: [],
  fetchMovieByTitle: async () => {},
  selectedMovie: null,
  uploadMovie: async () => {},
});

type ProviderProps = { children: ReactNode }

export const useMovies = () => {
  const context = useContext(MoviesContext);
  if (context === undefined) {
    throw new Error('useMovies must be used within a MoviesProvider');
  }
  return context;
};

export const MoviesProvider: React.FC<ProviderProps> = ({ children }) => {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);

  const fetchMovies = async () => {
    try {
      const response = await fetch('http://localhost:2323/movies');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setMovies(data); 
    } catch (error) {
      console.error('Failed to fetch movies:', error);
    }
  };

  useEffect(() => {
    fetchMovies();
  }, []);

 const fetchMovieByTitle = async (title: string) => {
  const encodedTitle = encodeURIComponent(title);
  const url = `http://localhost:2323/movies/title/${encodedTitle}`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    const data = await response.json();
    console.log(`Movie with title "${title}":`, data);
    setSelectedMovie(data);
  } catch (error) {
    console.error(`Error fetching movie with title "${title}":`, error);
    setSelectedMovie(null);
  }
};
  const uploadMovie = async (movieData: MovieData) => {
    try {
      console.log('Data being sent:', JSON.stringify(movieData));
      const response = await fetch('http://localhost:2323/movies/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(movieData),
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.message || 'Failed to upload movie');
      }


    
      console.log('Movie uploaded successfully!');
    } catch (error) {
      console.error('Failed to upload movie:', error);
    }
  };

 

 

  return (
    <MoviesContext.Provider value={{
      movies,
      favorites: movies,
      recents: movies,
      fetchMovieByTitle,
      selectedMovie,
      uploadMovie
    }}>
      {children}
    </MoviesContext.Provider>
  );
};

export default MoviesProvider;


